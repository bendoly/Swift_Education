//
//  ResultViewController.swift
//  StartToCodeWithSwiftFinal
//
//  Created by Elliot Bendoly on 7/1/19.
//  Copyright © 2019 Smith, Sam. All rights reserved.
//

import UIKit

class ResultViewController: UIViewController {

    var responses: [Answer]!

    @IBOutlet weak var resultHeader: UILabel!
    @IBOutlet weak var resultDescription: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.hidesBackButton = true
        calculateQuizResult()
    }
    
    func calculateQuizResult() {
        var score: Int = 0
        //let responseTypes = responses.map { $0.shouldselect }
        for response in responses {
            if response.shouldselect {
                score += 1
            }
        }
        if score < 0 {
            score = 0
        }
        resultHeader.text = "Your score is \(score)"
        switch score {
        case 0:
            resultDescription.text = "Check out the OSU facts tab!"
        case 1:
            resultDescription.text = "Check out the OSU facts tab!"
        case 2:
            resultDescription.text = "You know a decent amount about OSU"
        case 3:
            resultDescription.text = "You know a decent amount about OSU"
        default:
            resultDescription.text = "You know a lot about OSU!"
        }
        answersChosen = []
        questionIndex = 0
    }
    
    //RECAP:
    //struct Answer {
    // var text: String
    // var shouldselect: Bool
    //}
    //let currentQuestion = questions[questionIndex]
    //let currentAnswers = currentQuestion.answers
    //var answersChosen: [Answer] = []
    //answersChosen.append(currentAnswers[3])
    // so answersChosen is a collection of things chosen, literally {both good and bad}
    //we want to add as many "good" things as we can... and we know the max is 4...
    // so we just need to add up the things that are shouldselect=true

}
