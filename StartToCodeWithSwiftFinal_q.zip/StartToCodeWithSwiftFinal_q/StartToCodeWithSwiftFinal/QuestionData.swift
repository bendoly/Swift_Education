//
//  QuestionData.swift
//  StartToCodeWithSwiftFinal
//
//  Created by Elliot Bendoly on 7/1/19.
//  Copyright © 2019 Smith, Sam. All rights reserved.
//

import Foundation

struct Question {
    var text: String
    var type: ResponseType
    var answers: [Answer] = []
}
//Question.answers.removeAll()

enum ResponseType {
    case single, multiple
}

struct Answer {
    var text: String
    var shouldselect: Bool
}

var answersChosen: [Answer] = []
var questionIndex: Int = 0

var questions: [Question] = [
    Question(text: "What were OSU's original colors?", type: .single,
             answers: [
                Answer(text: "  Black and orange  ", shouldselect: true),
                Answer(text: "   Red and white    ", shouldselect: false),
                Answer(text: "   Gray and yellow  ", shouldselect: false),
                Answer(text: "  Scarlet and gray  ", shouldselect: false)
        ]),
    Question(text: "Who are some notable OSU graduates?", type: .multiple,
             answers: [
                Answer(text: "R. L. Stine        ", shouldselect: true),
                Answer(text: "Jesse Owens        ", shouldselect: true),
                Answer(text: "Taylor Swift       ", shouldselect: false),
                Answer(text: "Joss Whedon        ", shouldselect: false)
        ]),
    Question(text: "When was OSU founded?", type: .single,
             answers: [
                Answer(text: "   1870   ", shouldselect: true),
                Answer(text: "   1865   ", shouldselect: false),
                Answer(text: "   1860   ", shouldselect: false),
                Answer(text: "   1875   ", shouldselect: false)
                    ])
]


