//
//  ViewController.swift
//  StartToCodeWithSwiftFinal
//
//  Created by Smith, Sam on 5/21/19.
//  Copyright © 2019 Smith, Sam. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.hidesBackButton = true
        // Do any additional setup after loading the view.
    }

    @IBAction func unwindToQuizIntroduction(segue: UIStoryboardSegue) {
        answersChosen = []
        questionIndex = 0
    }
}

