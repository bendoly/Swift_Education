//
//  AccessibilityIdentifiers.swift
//  StartToCodeWithSwiftFinal
//
//  Created by Smith, Sam on 6/14/19.
//  Copyright © 2019 Smith, Sam. All rights reserved.
//

import Foundation

enum IDs: String {
    case firstFact                              
    case secondFact
    case thirdFact
    
    case firstCorrectMultipleChoiceSwitch
    case secondCorrectMultipleChoiceSwitch
    case firstIncorrectMultipleChoiceSwitch
    case secondIncorrectMultipleChoiceSwitch
    
    case firstMultipleChoiceLabel
    case secondMultipleChoiceLabel
    case thirdMultipleChoiceLabel
    case fourthMultipleChoiceLabel
    
    case submitAnswerButton
    case questionLabel
    case progressBar
    
    case correctAnswerButton
    case firstIncorrectAnswerButton
    case secondIncorrectAnswerButton
    case thirdIncorrectAnswerButton
    
    case resultHeader
    case resultDescription
}
