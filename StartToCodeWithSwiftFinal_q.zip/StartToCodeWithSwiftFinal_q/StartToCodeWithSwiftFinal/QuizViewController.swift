//
//  QuizViewController.swift
//  StartToCodeWithSwiftFinal
//
//  Created by Elliot Bendoly on 7/1/19.
//  Copyright © 2019 Smith, Sam. All rights reserved.
//

import UIKit

class QuizViewController: UIViewController {

   // var questionIndex = 0
    
    @IBOutlet weak var multipleStackView: UIStackView!
    @IBOutlet weak var singleStackView: UIStackView!
    @IBOutlet weak var questionLabel: UILabel!
    
    @IBOutlet weak var correctAnswerButton: UIButton!
    @IBOutlet weak var firstIncorrectAnswerButton: UIButton!
    @IBOutlet weak var secondIncorrectAnswerButton: UIButton!
    @IBOutlet weak var thirdIncorrectAnswerButton: UIButton!
    
    @IBOutlet weak var firstCorrectMultipleChoiceLabel: UILabel!
    @IBOutlet weak var secondCorrectMultipleChoiceLabel: UILabel!
    @IBOutlet weak var firstIncorrectMultipleChoiceLabel: UILabel!
    @IBOutlet weak var secondIncorrectMultipleChoiceLabel: UILabel!
    
    @IBOutlet weak var firstCorrectMultipleChoiceSwitch: UISwitch!
    @IBOutlet weak var secondCorrectMultipleChoiceSwitch: UISwitch!
    @IBOutlet weak var firstIncorrectMultipleChoiceSwitch: UISwitch!
    @IBOutlet weak var secondIncorrectMultipleChoiceSwitch: UISwitch!
    
    @IBOutlet weak var questionProgressView: UIProgressView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        updateUI()
    }
    
    func updateUI() {
        singleStackView.isHidden = true
        multipleStackView.isHidden = true
        
        let currentQuestion = questions[questionIndex]
        let currentAnswers = currentQuestion.answers
        let totalProgress = Float(questionIndex)/Float(questions.count)
        
        navigationItem.title = "Question #\(questionIndex+1)"
        questionLabel.text = currentQuestion.text
        questionProgressView.setProgress(totalProgress, animated: true)
        
        func updateSingleStackView(using answers: [Answer]) {
            singleStackView.isHidden = false
            correctAnswerButton.setTitle(answers[0].text, for: .normal)
            firstIncorrectAnswerButton.setTitle(answers[1].text, for: .normal)
            secondIncorrectAnswerButton.setTitle(answers[2].text, for: .normal)
            thirdIncorrectAnswerButton.setTitle(answers[3].text, for: .normal)
        }
        func updateMultipleStackView(using answers: [Answer]) {
            multipleStackView.isHidden = false
            firstCorrectMultipleChoiceSwitch.isOn = false
            secondCorrectMultipleChoiceSwitch.isOn = false
            firstIncorrectMultipleChoiceSwitch.isOn = false
            secondIncorrectMultipleChoiceSwitch.isOn = false
            firstCorrectMultipleChoiceLabel.text = answers[0].text
            secondCorrectMultipleChoiceLabel.text = answers[1].text
            firstIncorrectMultipleChoiceLabel.text = answers[2].text
            secondIncorrectMultipleChoiceLabel.text = answers[3].text
        }
        
        switch currentQuestion.type {
        case .single:
            updateSingleStackView(using: currentAnswers)
        case .multiple:
            updateMultipleStackView(using: currentAnswers)
        }
    }
    
    @IBAction func singleActionButtonPressed(_ sender: UIButton) {
       let currentAnswers = questions[questionIndex].answers
        switch sender{
        case correctAnswerButton:
            answersChosen.append(currentAnswers[0])
        case firstIncorrectAnswerButton:
            answersChosen.append(currentAnswers[1])
        case secondIncorrectAnswerButton:
            answersChosen.append(currentAnswers[2])
        case thirdIncorrectAnswerButton:
            answersChosen.append(currentAnswers[3])
        default:
            break
        }
        nextQuestion()
    }
    
    @IBAction func multipleAnswerButtonPressed() {
    let currentAnswers = questions[questionIndex].answers
        if firstCorrectMultipleChoiceSwitch.isOn {
            answersChosen.append(currentAnswers[0])
        }
        if secondCorrectMultipleChoiceSwitch.isOn {
            answersChosen.append(currentAnswers[1])
        }
        if firstIncorrectMultipleChoiceSwitch.isOn {
            answersChosen.append(currentAnswers[2])
        }
        if secondIncorrectMultipleChoiceSwitch.isOn {
            answersChosen.append(currentAnswers[3])
        }
        nextQuestion()
    }
    
    func nextQuestion() {
        questionIndex += 1
        if questionIndex < questions.count {
            updateUI()
        } else {
          performSegue(withIdentifier: "ResultsSegue", sender: nil)
            answersChosen = []
            questionIndex = 0
            updateUI()
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "ResultsSegue" {
            let resultsViewController = segue.destination as! ResultViewController
            resultsViewController.responses = answersChosen
        }
    }

}
