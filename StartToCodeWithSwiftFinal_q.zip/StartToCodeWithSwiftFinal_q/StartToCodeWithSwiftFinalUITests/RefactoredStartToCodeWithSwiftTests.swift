//
//  RefactoredStartToCodeWithSwiftTests.swift
//  StartToCodeWithSwiftFinalUITests
//
//  Created by Smith, Sam on 6/14/19.
//  Copyright © 2019 Smith, Sam. All rights reserved.
//

import XCTest


class RefactoredStartToCodeWithSwiftTests: XCTestCase {
    
    // MARK: - Test Methods
    
    override func setUp() {
        continueAfterFailure = false

        let app = XCUIApplication()
        setupSnapshot(app)
        app.launch()
        
    }

    override func tearDown() {
    }

    /// Welcome Screen test - this screen should have three UILabels for facts
    func testWelcomeScreenHasThreeFacts() {
        // given
        let app = XCUIApplication()
        
        // then
        assertWelcomeScreenElementsExist(in: app)
        
        snapshot("01WelcomeScreen")
    }
    
    /// Single Answer Test Screen test - this screen should have a UILabel, 4 UIButtons, and a UIProgressView
    func testSelectingTakeQuizOpensFirstSingleChoiceQuestion() {
        // given
        let app = XCUIApplication()
        
        // when
        navigateToFirstQuestion(in: app)
        
        // then
        assertSingleAnswerButtonsExist(in: app)
        
        snapshot("02FirstSingleChoiceQuestion")
    }
    
    /// Multiple Answer Test Screen test - this screen should have 5 UILabels, 4 UISwitches, a UIButton, and a UIProgressView
    func testAnsweringFirstQuestionLeadsToSecondQuestion() {
        // given
        let app = XCUIApplication()
        
        // when
        navigateToSecondQuestion(in: app)
        
        // then
        assertMultipleChoiceAnswerScreenExists(in: app)
        
        snapshot("03FirstMultipleChoiceQuestion")
    }
    
    /// Second Single Answer Test Screen test - this screen should have a UILabel, 4 UIButtons, and a UIProgressView
    func testAnsweringSecondQuestionLeadsToThirdQuestion() {
        // given
        let app = XCUIApplication()
        
        // when
        navigateToThirdQuestion(in: app)
        
        // then
        assertSingleAnswerButtonsExist(in: app)
        
        snapshot("04SecondSingleChoiceQuestion")
    }
    
    // Final Results screen test - this screen should have 2 UILabels
    func testAnsweringThirdQuestionLeadsToAnswerScreen() {
        // given
        let app = XCUIApplication()
        
        // when
        navigateToResultScreen(in: app)
        
        // then
        assertResultsScreenElementsExist(in: app)
        
        snapshot("05ResultScreenScoreOf2")
    }
    
    func testPressingDoneGoesBackToTriviaScreen() {
        // given
        let app = XCUIApplication()
        
        // when
        navigateToResultScreen(in: app)
        app.buttons["Done"].tap()
        
        //then
        assertWelcomeScreenElementsExist(in: app)
    }
    
    func testGetting1ScoreScreenshot() {
        let app = XCUIApplication()
        navigateToResultScreenWithAScoreOf1(in: app)
    }
    
    func testGetting2ScoreScreenshot() {
        let app = XCUIApplication()
        navigateToResultScreenWithAScoreOf2(in: app)
    }
    
    func testGetting3ScoreScreenshot() {
        let app = XCUIApplication()
        navigateToResultScreenWithAScoreOf3(in: app)
    }
    
    func testGetting4ScoreScreenshot() {
        let app = XCUIApplication()
        navigateToResultScreenWithAScoreOf4(in: app)
    }
    
    // MARK: - Assertion Helper Methods
    
    func assertResultsScreenElementsExist(in app: XCUIApplication) {
        XCTAssertTrue(app.staticTexts[IDs.resultHeader.rawValue].exists, addErrorMessageForLabel(withIdentifier: .resultHeader, forScreen: "result screen"))
        XCTAssertTrue(app.staticTexts[IDs.resultDescription.rawValue].exists, addErrorMessageForLabel(withIdentifier: .resultDescription, forScreen: "result screen"))
    }
    
    func assertWelcomeScreenElementsExist(in app: XCUIApplication) {
        XCTAssertTrue(app.staticTexts[IDs.firstFact.rawValue].exists, addErrorMessageForLabel(withIdentifier: IDs.firstFact, forScreen: "welcome screen"))
        XCTAssertTrue(app.staticTexts[IDs.secondFact.rawValue].exists, addErrorMessageForLabel(withIdentifier: IDs.secondFact, forScreen: "welcome screen"))
        XCTAssertTrue(app.staticTexts[IDs.thirdFact.rawValue].exists, addErrorMessageForLabel(withIdentifier: IDs.thirdFact, forScreen: "welcome screen"))
    }
    
    func assertCommonQuizElementsExist(in app: XCUIApplication) {
        XCTAssertTrue(app.staticTexts[IDs.questionLabel.rawValue].exists, addErrorMessageForLabel(withIdentifier: IDs.questionLabel, forScreen: "quiz screen"))
        XCTAssertTrue(app.progressIndicators[IDs.progressBar.rawValue].exists, addErrorMessageForProgressBar(withIdentifier: IDs.progressBar, forScreen: "quiz screen"))
    }
    
    func assertSingleAnswerButtonsExist(in app: XCUIApplication) {
        assertCommonQuizElementsExist(in: app)
        
        XCTAssertTrue(app.buttons[IDs.correctAnswerButton.rawValue].exists, addErrorMessageForButton(withIdentifier: .correctAnswerButton, forScreen: "quiz screen"))
        XCTAssertTrue(app.buttons[IDs.firstIncorrectAnswerButton.rawValue].exists, addErrorMessageForButton(withIdentifier: .firstIncorrectAnswerButton, forScreen: "quiz screen"))
        XCTAssertTrue(app.buttons[IDs.secondIncorrectAnswerButton.rawValue].exists, addErrorMessageForButton(withIdentifier: .secondIncorrectAnswerButton, forScreen: "quiz screen"))
        XCTAssertTrue(app.buttons[IDs.thirdIncorrectAnswerButton.rawValue].exists, addErrorMessageForButton(withIdentifier: .thirdIncorrectAnswerButton, forScreen: "quiz screen"))
    }
    
    func assertMultipleChoiceAnswerScreenExists(in app: XCUIApplication) {
        // Assert the common elements exist
        assertCommonQuizElementsExist(in: app)
        
        // Assert the switches exist
        XCTAssertTrue(app.switches[IDs.firstCorrectMultipleChoiceSwitch.rawValue].exists, addErrorMessageForSwitch(withIdentifier: .firstCorrectMultipleChoiceSwitch, forScreen: "quiz screen"))
        XCTAssertTrue(app.switches[IDs.secondCorrectMultipleChoiceSwitch.rawValue].exists, addErrorMessageForSwitch(withIdentifier: .secondCorrectMultipleChoiceSwitch, forScreen: "quiz screen"))
        XCTAssertTrue(app.switches[IDs.firstIncorrectMultipleChoiceSwitch.rawValue].exists, addErrorMessageForSwitch(withIdentifier: .firstIncorrectMultipleChoiceSwitch, forScreen: "quiz screen"))
        XCTAssertTrue(app.switches[IDs.secondIncorrectMultipleChoiceSwitch.rawValue].exists, addErrorMessageForSwitch(withIdentifier: .secondIncorrectMultipleChoiceSwitch, forScreen: "quiz screen"))
        
        // Assert the labels exist
        XCTAssertTrue(app.staticTexts[IDs.firstMultipleChoiceLabel.rawValue].exists, addErrorMessageForLabel(withIdentifier: .firstMultipleChoiceLabel, forScreen: "quiz screen"))
        XCTAssertTrue(app.staticTexts[IDs.secondMultipleChoiceLabel.rawValue].exists, addErrorMessageForLabel(withIdentifier: .secondMultipleChoiceLabel, forScreen: "quiz screen"))
        XCTAssertTrue(app.staticTexts[IDs.thirdMultipleChoiceLabel.rawValue].exists, addErrorMessageForLabel(withIdentifier: .thirdMultipleChoiceLabel, forScreen: "quiz screen"))
        XCTAssertTrue(app.staticTexts[IDs.fourthMultipleChoiceLabel.rawValue].exists, addErrorMessageForLabel(withIdentifier: .fourthMultipleChoiceLabel, forScreen: "quiz screen"))
        
        // Assert the button exists
        XCTAssertTrue(app.buttons[IDs.submitAnswerButton.rawValue].exists, addErrorMessageForButton(withIdentifier: .submitAnswerButton, forScreen: "quiz screen"))
    }
    
    // MARK: - Navigation Helper Methods
    
    func navigateToFirstQuestion(in app: XCUIApplication) {
        app.tabBars.buttons["Take the Quiz"].tap()
    }
    
    func navigateToSecondQuestion(in app: XCUIApplication) {
        navigateToFirstQuestion(in: app)
        
        app.buttons[IDs.firstIncorrectAnswerButton.rawValue].tap()
    }
    
    func navigateToThirdQuestion(in app: XCUIApplication) {
        navigateToSecondQuestion(in: app)
        
        app.buttons[IDs.submitAnswerButton.rawValue].tap()
    }
    
    func navigateToResultScreen(in app: XCUIApplication) {
        navigateToThirdQuestion(in: app)
        
        app.buttons[IDs.firstIncorrectAnswerButton.rawValue].tap()
    }
    
    func navigateToResultScreenWithAScoreOf0(in app: XCUIApplication) {
        navigateToFirstQuestion(in: app)
        
        app.buttons[IDs.firstIncorrectAnswerButton.rawValue].tap()
        app.buttons[IDs.submitAnswerButton.rawValue].tap()
        app.buttons[IDs.firstIncorrectAnswerButton.rawValue].tap()
        
        
    }
    
    func navigateToResultScreenWithAScoreOf1(in app: XCUIApplication) {
        navigateToFirstQuestion(in: app)
        
        app.buttons[IDs.correctAnswerButton.rawValue].tap()
        app.buttons[IDs.submitAnswerButton.rawValue].tap()
        app.buttons[IDs.firstIncorrectAnswerButton.rawValue].tap()
        
        snapshot("06ScoreOf1")
    }
    
    func navigateToResultScreenWithAScoreOf2(in app: XCUIApplication) {
        navigateToFirstQuestion(in: app)
        
        app.buttons[IDs.correctAnswerButton.rawValue].tap()
        app.buttons[IDs.submitAnswerButton.rawValue].tap()
        app.buttons[IDs.correctAnswerButton.rawValue].tap()
        
        snapshot("07ScoreOf2")
    }
    
    func navigateToResultScreenWithAScoreOf3(in app: XCUIApplication) {
        navigateToFirstQuestion(in: app)
        
        app.buttons[IDs.correctAnswerButton.rawValue].tap()
        app.switches[IDs.firstCorrectMultipleChoiceSwitch.rawValue].tap()
        app.buttons[IDs.submitAnswerButton.rawValue].tap()
        app.buttons[IDs.correctAnswerButton.rawValue].tap()
        
        snapshot("08ScoreOf3")
    }
    
    func navigateToResultScreenWithAScoreOf4(in app: XCUIApplication) {
        navigateToFirstQuestion(in: app)
        
        app.buttons[IDs.correctAnswerButton.rawValue].tap()
        app.switches[IDs.firstCorrectMultipleChoiceSwitch.rawValue].tap()
        app.switches[IDs.secondCorrectMultipleChoiceSwitch.rawValue].tap()
        app.buttons[IDs.submitAnswerButton.rawValue].tap()
        app.buttons[IDs.correctAnswerButton.rawValue].tap()
        
        snapshot("09ScoreOf4")
    }
    
    // MARK: - Error Message Helper Methods
    
    func addErrorMessageForLabel(withIdentifier accessibilityIdentifier: IDs, forScreen screen: String) -> String {
        return "The \(screen) is missing the \"\(accessibilityIdentifier)\" label. Remember to add a label and set the Accessibility Identifier with labelName.accessibilityIdentifier = IDs.labelID.rawValue in the view controller's viewDidLoad() method."
    }
    
    func addErrorMessageForButton(withIdentifier accessibilityIdentifier: IDs, forScreen screen: String) -> String {
        return "The \(screen) is missing the \"\(accessibilityIdentifier)\" button. Remember to add a button and set the Accessibility Identifier with buttonName.accessibilityIdentifier = IDs.buttonID.rawValue in the view controller's viewDidLoad() method."
    }
    
    func addErrorMessageForProgressBar(withIdentifier accessibilityIdentifier: IDs, forScreen screen: String) -> String {
        return "The \(screen) is missing the \"\(accessibilityIdentifier)\" progress view. Remember to add a progress view and set the Accessibility Identifier with progressViewName.accessibilityIdentifier = IDs.progressViewID.rawValue in the view controller's viewDidLoad() method."
    }
    
    func addErrorMessageForSwitch(withIdentifier accessibilityIdentifier: IDs, forScreen screen: String) -> String {
        return "The \(screen) is missing the \"\(accessibilityIdentifier)\" switch. Remember to add a switch and set the Accessibility Identifier with switchName.accessibilityIdentifier = IDs.switchID.rawValue in the view controller's viewDidLoad() method."
    }
}
